<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GroupbuyAdminController extends Controller
{
    protected function index(){
        return $this->view();
    }

    protected function login(){
        extract($this->post);
        $data = $this->db->table('admin_users')->where('username', $username)->where('password', $password)->where('type', 0)->get();
        if(count($data)){
            $data[0]->isLogin = true;
            $this->request->session()->put($this->project."_login_data", $data[0]);
            return true;
        }
        return false;
    }

    protected function logout(){
        $this->request->session()->forget($this->project."_login_data");
        return redirect('/groupbuyVendor/index');
    }

    protected function dashboard(){
        return $this->view();
    }

    protected function convenerAccount(){
        return $this->view();
    }
}
