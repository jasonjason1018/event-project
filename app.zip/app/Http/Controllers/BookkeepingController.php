<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \DateTime; 

class BookkeepingController extends Controller
{
    protected function index(){
        $isLogin = $this->request->session()->get($this->project.'_login_data')->isLogin??false;
        if($isLogin){
            return redirect('/bookkeeping/accountForm');
        }
        return $this->view();
    }

    protected function login(){
        extract($this->post);
        
        $data = $this->db->table('admin_users')->where('username', $username)->where('password', $password)->get();
        if(count($data)){
            $data[0]->isLogin = true;
            $this->request->session()->put($this->project."_login_data", $data[0]);
            return true;
        }
        return false;
    }

    protected function logout(){
        $this->request->session()->forget($this->project."_login_data");
        return redirect('/bookkeeping/index');
    }

    protected function accountForm($param = 0){
        if($param){
            return view("$this->project.$this->path", ['param' => $param]);
        }
        return $this->view();
    }

    protected function getAccountData(){
        extract($this->post);
        return $this->db->table('accountDetails')->where('id', $id)->get();
    }

    protected function saveForm(){
        extract($this->post);
        if(isset($this->post['img'])){
            unset($this->post['img']);
            $this->post['img'] = $this->post['imgList'];
        }
        if(isset($this->post['imgList'])){
            unset($this->post['imgList']);
        }
        if(isset($id)){
            
            $this->db->table('accountDetails')->where('id', $id)->update($this->post);
        }else{
            $id = $this->db->table('accountDetails')->insertGetId($this->post);
        }
        if($share){
            $shareData = [
                'id' => $id,
                'start_share_date' => $start_share_date,
                'end_share_date' => $end_share_date,
                'price' => $price
            ];
            $this->saveShareDetail($shareData);
        }
    }

    private function saveShareDetail($shareData = []){
        $price = $shareData['price'];
        $start = new DateTime($shareData['start_share_date']);
        $end = new DateTime($shareData['end_share_date']);
        $account_id = $shareData['id'];
        $interval = date_diff($start, $end);
        $months = ($interval->y *12) + $interval->m;
        $monthPrice = floor($price/($months+1));
        
        $total = 0;
        while(true){
            $thisMonthPrice = $monthPrice;
            if($start->format('Y') == $end->format('Y') && $start->format('m') == $end->format('m')){
                $thisMonthPrice = $price - $total;
            }
            $db_data = [
                'account_id' => 1,
                'amount' => $thisMonthPrice,
                'date' => $start->format('Y-m')
            ];
            $this->db->table('shareDetails')->insert($db_data);
            $total +=  $thisMonthPrice;
            // 下個月
            $year = $start->format('Y');
            $month = $start->format('m')+1;
            if($month > 12){
                $month = 1;
                $year += 1;
            }
            $newDate = $year.'-'.$month.'-01';
            $start = new DateTime($newDate);
            if($year == $end->format('Y') && $month > $end->format('m')){
                break;
            }
        }
    }

    protected function uploadImg(Request $request){
        $file = $request->file('file');
        $fileName = date('YmdHis') . '_' . $file->getClientOriginalName();
        $file->move(public_path('uploads'), $fileName);
        return $fileName;
    }

    protected function ledgerEntry(){
        return $this->view();
    }

    protected function getLedgerEntryList(){
        return $this->db->table('ledgerEntry')->get();
    }

    protected function saveLedgerEntry(){
        unset($this->post['title']);
        $this->post['update_at'] = $this->getTime();
        if(isset($this->post['id'])){
            $this->db->table('ledgerEntry')->where('id', $this->post['id'])->update($this->post);
            return ;
        }
        $this->post['create_at'] = $this->getTime();
        $this->db->table('ledgerEntry')->insert($this->post);
    }

    protected function ledgerEntryDelete(){
        $this->db->table('ledgerEntry')->where('id', $this->post['id'])->delete();
    }

    private function getTime(){
        date_default_timezone_set("Asia/Taipei");
		return date("Y-m-d H:i:s");
    }

    protected function accountList(){
        return $this->view();
    }

    protected function getAccountList(){
        return $this->db->table('accountDetails')->get();
    }

    protected function accountDelete(){
        extract($this->post);
        $this->db->table('accountDetails')->where('id', $id)->delete();
    }

    protected function accountDetail($param){
        return view("$this->project.$this->path", ['param' => $param]);
    }
}
